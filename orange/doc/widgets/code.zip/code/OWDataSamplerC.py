"""
<name>Data Sampler (C)</name>
<description>Randomly selects a subset of instances from the data set</description>
<icon>icons/DataSamplerC.png</icon>
<priority>30</priority>
"""
from OWWidget import *
import OWGUI

class OWDataSamplerC(OWWidget):
    settingsList = ['proportion', 'commitOnChange']
    def __init__(self, parent=None):
        OWWidget.__init__(self, parent, 'SampleDataB')
        
        self.inputs = [("Data", ExampleTable, self.data)]
        self.outputs = [("Sampled Data", ExampleTable), ("Other Data", ExampleTable)]

        self.proportion = 50
        self.commitOnChange = 0
        self.loadSettings()

        # GUI
        box = QVGroupBox("Info", self.controlArea)
        self.infoa = QLabel('No data on input yet, waiting to get something.', box)
        self.infob = QLabel('', box)

        OWGUI.separator(self.controlArea)
        self.optionsBox = QVGroupBox("Options", self.controlArea)
        OWGUI.spin(self.optionsBox, self, 'proportion', min=10, max=90, step=10,
                   label='Sample Size [%]:', callback=[self.selection, self.checkCommit])
        OWGUI.checkBox(self.optionsBox, self, 'commitOnChange', 'Commit data on selection change')
        OWGUI.button(self.optionsBox, self, "Commit", callback=self.commit)
        self.optionsBox.setDisabled(1)

        self.resize(100,50)

    def data(self, dataset):
        if dataset:
            self.dataset = dataset
            self.infoa.setText('%d instances in input data set' % len(dataset))
            self.optionsBox.setDisabled(0)
            self.selection()
            self.commit()
        else:
            self.send("Sampled Data", None)
            self.optionsBox.setDisabled(1)
            self.infoa.setText('No data on input yet, waiting to get something.')
            self.infob.setText('')

    def selection(self):
        indices = orange.MakeRandomIndices2(p0=self.proportion / 100.)
        ind = indices(self.dataset)
        self.sample = self.dataset.select(ind, 0)
        self.otherdata = self.dataset.select(ind, 1)
        self.infob.setText('%d sampled instances' % len(self.sample))

    def commit(self):
        self.send("Sampled Data", self.sample)
        self.send("Other Data", self.otherdata)

    def checkCommit(self):
        if self.commitOnChange:
            self.commit()

##############################################################################
# Test the widget, run from prompt

if __name__=="__main__":
    appl = QApplication(sys.argv)
    ow = OWDataSamplerC()
    appl.setMainWidget(ow)
    ow.show()
    dataset = orange.ExampleTable('iris.tab')
    ow.data(dataset)
    appl.exec_loop()
